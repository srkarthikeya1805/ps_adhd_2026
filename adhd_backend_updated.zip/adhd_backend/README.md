# Universal EEG ADHD Detection Backend

Production & research-grade backend for:
**"The Hybrid Deep Learning Model for Identification of Attention-Deficit/Hyperactivity Disorder Using EEG"**

This backend enables users and researchers to upload raw EEG recordings in diverse formats (`.mat`, `.csv`, `.tsv`, `.npy`, `.npz`, `.edf`, and `.zip` archives) and obtain ADHD vs. Control research predictions using the trained **CNN + Transformer** deep-learning model (`.keras`).

---

## Architecture Overview

```text
Uploaded EEG File(s) / ZIP
        ↓
Universal EEG File Detector & Parser
(MAT numeric/structured, CSV, TSV, NPY, NPZ, EDF, ZIP)
        ↓
EEG Structure & Orientation Validation
        ↓
Channel Mapping & Reordering to 19 Model Channels:
[Fp1, Fp2, F7, F3, Fz, F4, F8, T3, C3, Cz, C4, T4, T5, P3, Pz, P4, T6, O1, O2]
        ↓
Polyphase Resampling to 128 Hz
        ↓
Bandpass Filtering: 1–45 Hz (Butterworth 4th Order)
        ↓
Powerline Notch Filtering: 50 Hz
        ↓
Per-channel Z-score Normalization: (x - μ) / σ
        ↓
10-second Windowing (50% Overlap) → (num_windows, 1280, 19)
        ↓
Trained CNN + Transformer Model (.keras)
        ↓
Window-level Predictions & Metrics
        ↓
Subject / File-level Aggregation
        ↓
Prediction (ADHD / Control) + Probability + Detailed Processing Report
```

---

## Project Structure

```text
d:\adhd_backend\
├── app/
│   ├── main.py                  # FastAPI app with lifespan startup
│   ├── config.py                # Pipeline constants and channel aliases
│   │
│   ├── api/
│   │   ├── __init__.py          # Combined API router
│   │   ├── routes_health.py     # /health & /api/health
│   │   ├── routes_model.py      # /api/model/info
│   │   ├── routes_validate.py   # /api/validate
│   │   └── routes_predict.py    # /api/predict & /api/predict/batch
│   │
│   ├── model/
│   │   ├── model_loader.py      # PositionalEmbedding custom layer & ModelManager
│   │   └── inference.py         # Model prediction, input validation & aggregation
│   │
│   ├── parsers/
│   │   ├── base.py              # EEGRecording internal container
│   │   ├── mat_parser.py        # Numeric (IEEE) & structured/cell/object (Mendeley) parser
│   │   ├── csv_parser.py        # Tabular CSV parser + timestamp fs estimation
│   │   ├── tsv_parser.py        # Tab-separated EEG parser
│   │   ├── numpy_parser.py      # .npy and .npz parser
│   │   ├── edf_parser.py        # EDF, FIF, SET parser via MNE
│   │   └── zip_parser.py        # Safe recursive ZIP extraction
│   │
│   ├── preprocessing/
│   │   ├── channels.py          # 10-20 channel alias mapping & reordering
│   │   ├── resampling.py        # Polyphase signal resampling to 128 Hz
│   │   ├── filtering.py         # 1-45 Hz bandpass + 50 Hz notch
│   │   ├── normalization.py     # Per-channel z-score normalization
│   │   └── windowing.py         # 10s windowing (1280, 19) with 50% overlap
│   │
│   ├── validation/
│   │   ├── validator.py         # Universal file and signal structure validator
│   │   └── compatibility.py     # Strict tensor shape compatibility verifier
│   │
│   ├── schemas/
│   │   └── responses.py         # Pydantic response models
│   │
│   └── utils/
│       ├── logging.py           # Standardized pipeline logging
│       └── files.py             # Upload limits, safe naming & path traversal guards
│
├── models/
│   └── adhd_cnn_transformer_model.keras  # Trained deep learning model
│
├── tests/
│   ├── fixtures/                # Generated EEG files for test validation
│   ├── test_pipeline.py         # Unit tests for parsers, preprocessing & model
│   └── test_api.py              # API endpoint integration tests
│
├── main.py                      # Root entry point (re-exports app.main:app)
├── predict.py                   # Backward-compatible prediction interface
├── requirements.txt             # Project dependencies
└── README.md
```

---

## Model Location

The trained deep learning model is located at:

```text
models/adhd_cnn_transformer_model.keras
```

(Fallback path `models/model.keras` is also supported).

The model uses a custom `PositionalEmbedding` Keras layer and expects input shape `(batch, 1280, 19)` representing 10-second windows (1280 samples at 128 Hz) across 19 standard channels. The model produces a single sigmoid unit indicating the probability of ADHD ($1 = \text{ADHD}$, $0 = \text{Control}$).

---

## Supported Input Formats

| Format | Extension | Capabilities | Tested Status |
|---|---|---|---|
| **MATLAB Numeric** | `.mat` | 2D matrices (samples × channels or channels × samples), e.g. IEEE `v1p.mat`, `v21p.mat` | **Tested & Verified** |
| **MATLAB Structured** | `.mat` | Nested structs, cell arrays, and object arrays, e.g. Mendeley `FC.mat`, `MC.mat`, `FADHD.mat`, `MADHD.mat` | **Tested & Verified** |
| **MATLAB v7.3** | `.mat` | HDF5-based MAT archives | **Tested & Verified** |
| **CSV** | `.csv` | Comma-delimited with/without headers, auto time/timestamp detection | **Tested & Verified** |
| **TSV / TXT** | `.tsv`, `.txt` | Tab-delimited EEG recordings | **Tested & Verified** |
| **NumPy Array** | `.npy` | 2D NumPy array | **Tested & Verified** |
| **NumPy Archive** | `.npz` | Multi-array archive with metadata arrays | **Tested & Verified** |
| **EDF / BDF** | `.edf` | Standard European Data Format parsed with MNE | **Tested & Verified** |
| **EEGLAB / FIF** | `.set`, `.fif` | EEGLAB and Neuromag FIF recordings | **Tested & Verified** |
| **ZIP Archive** | `.zip` | Multi-file archive with recursive search and non-EEG file filtering | **Tested & Verified** |

---

## Installation & Setup

### Requirements

- Python 3.10, 3.11, 3.12, or 3.13
- Virtual environment recommended

### Install Dependencies

```powershell
pip install -r requirements.txt
```

---

## Running the Server

Run from the `d:\adhd_backend` directory:

```powershell
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

Or using root `main.py`:

```powershell
python main.py
```

The interactive OpenAPI documentation will be accessible at:
[http://localhost:8000/docs](http://localhost:8000/docs)

---

## API Endpoints

### 1. `GET /api/health` (or `/health`)
Checks backend operational status, model loading, and execution device (`CPU` or `GPU`).

```json
{
  "status": "healthy",
  "model_loaded": true,
  "device": "CPU",
  "version": "3.0.0"
}
```

### 2. `GET /api/model/info`
Exposes trained CNN-Transformer architecture, input/output tensor shapes, and channel ordering.

```json
{
  "model_loaded": true,
  "input_shape": [null, 1280, 19],
  "output_shape": [null, 1],
  "architecture": "CNN + Transformer",
  "sampling_rate": 128.0,
  "window_seconds": 10,
  "window_samples": 1280,
  "channels": 19,
  "channel_names": [
    "Fp1", "Fp2", "F7", "F3", "Fz", "F4", "F8",
    "T3", "C3", "Cz", "C4", "T4", "T5", "P3",
    "Pz", "P4", "T6", "O1", "O2"
  ],
  "device": "CPU",
  "total_params": 440961
}
```

### 3. `POST /api/validate`
Validates EEG file(s) or ZIP archives without executing neural network inference. Returns validation reports indicating shape, sampling frequency, channels, duration, and pipeline compatibility.

**Parameters:**
- `files`: One or more files (or a `.zip` archive)
- `sampling_rate` (optional): Sampling frequency override if metadata is absent.

### 4. `POST /api/predict` (and `/api/predict/batch`, `/predict-adhd`)
Processes one or multiple EEG files or a ZIP archive through the complete preprocessing and CNN-Transformer inference pipeline.

**Example Response:**
```json
{
  "batch_type": "single_file",
  "summary": {
    "total_files": 1,
    "successful_files": 1,
    "failed_files": 0,
    "adhd_predictions": 1,
    "control_predictions": 0
  },
  "results": [
    {
      "filename": "v1p.csv",
      "status": "success",
      "prediction": "ADHD",
      "adhd_probability": 0.8412,
      "confidence": 0.8412,
      "mean_adhd_probability": 0.8412,
      "median_adhd_probability": 0.852,
      "adhd_window_percentage": 100.0,
      "total_windows": 2,
      "details": {
        "source": "Tabular (.csv)",
        "format": ".csv",
        "sampling_rate_used": 128.0,
        "resampled": false,
        "original_shape": [1920, 19],
        "preprocessed_shape": [1920, 19],
        "channels_used": 19,
        "channel_names": [
          "Fp1", "Fp2", "F7", "F3", "Fz", "F4", "F8",
          "T3", "C3", "Cz", "C4", "T4", "T5", "P3",
          "Pz", "P4", "T6", "O1", "O2"
        ],
        "duration_seconds": 15.0,
        "window_seconds": 10,
        "window_samples": 1280,
        "overlap": 0.5,
        "windows": 2,
        "window_probabilities": [0.8304, 0.8520],
        "window_predictions": [
          {
            "window": 1,
            "start_seconds": 0.0,
            "end_seconds": 10.0,
            "adhd_probability": 0.8304,
            "prediction": "ADHD"
          },
          {
            "window": 2,
            "start_seconds": 5.0,
            "end_seconds": 15.0,
            "adhd_probability": 0.852,
            "prediction": "ADHD"
          }
        ]
      },
      "research_disclaimer": "Research classification only. This model output is for investigative purposes and does not constitute a clinical medical diagnosis."
    }
  ],
  "status": "success"
}
```

---

## Running the Automated Test Suite

To run all 28 automated unit, parser, preprocessing, and API integration tests:

```powershell
python -m pytest -v
```
