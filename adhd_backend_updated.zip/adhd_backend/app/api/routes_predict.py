import shutil
import tempfile
from pathlib import Path
from typing import List, Optional
from fastapi import APIRouter, File, Form, HTTPException, UploadFile

from app.model.inference import run_inference
from app.parsers import parse_eeg_file
from app.parsers.zip_parser import extract_zip_archive_safely
from app.preprocessing import process_eeg_recording
from app.schemas.responses import (
    BatchPredictionResponse,
    BatchSummary,
    FilePredictionDetails,
    FilePredictionResult,
    WindowPrediction,
)
from app.utils.files import (
    copy_upload_with_limit,
    infer_folder_label,
    safe_upload_filename,
    validate_extension,
)
from app.utils.logging import log_pipeline_step
from app.validation.compatibility import check_tensor_compatibility

router = APIRouter(tags=["Prediction"])


def predict_single_eeg_file(
    path: Path,
    display_name: str,
    sampling_rate_override: Optional[float] = None
) -> FilePredictionResult:
    """
    Process one EEG file through the entire pipeline:
    Parse -> Orient -> Resample -> Filter -> Normalize -> Window -> CNN-Transformer -> Aggregate
    """
    try:
        # 1. Universal Parse
        recording = parse_eeg_file(path, sampling_rate_override=sampling_rate_override)
        original_shape = list(recording.original_shape)
        orig_fs = recording.sampling_rate

        # 2. Universal Preprocess
        X, continuous_preprocessed, final_fs, channel_names, warnings = process_eeg_recording(recording)

        # 3. Model compatibility check
        check_tensor_compatibility(X)

        # 4. Neural Network Inference
        mean_prob, pred_class, window_probs, window_records, agg_metrics = run_inference(X)

        duration_sec = round(len(continuous_preprocessed) / final_fs, 2)

        # 5. Build detailed result
        details = FilePredictionDetails(
            source=recording.source_format,
            format=path.suffix.lower(),
            sampling_rate_original=orig_fs,
            sampling_rate_used=final_fs,
            resampled=abs(float(orig_fs or final_fs) - final_fs) > 1e-4,
            original_shape=original_shape,
            preprocessed_shape=list(continuous_preprocessed.shape),
            channels_original=recording.original_shape[1] if len(recording.original_shape) == 2 else 19,
            channels_used=19,
            channel_names=channel_names,
            duration_seconds=duration_sec,
            window_seconds=10,
            window_samples=1280,
            overlap=0.50,
            windows=len(X),
            warnings=warnings,
            window_probabilities=window_probs,
            window_predictions=[WindowPrediction(**w) for w in window_records]
        )

        return FilePredictionResult(
            filename=display_name,
            status="success",
            prediction=pred_class,
            adhd_probability=round(mean_prob, 6),
            confidence=agg_metrics["confidence"],
            mean_adhd_probability=agg_metrics["mean_adhd_probability"],
            median_adhd_probability=agg_metrics["median_adhd_probability"],
            adhd_window_percentage=agg_metrics["adhd_window_percentage"],
            total_windows=len(X),
            folder_context=infer_folder_label(display_name),
            details=details
        )

    except Exception as exc:
        return FilePredictionResult(
            filename=display_name,
            status="failed",
            error=str(exc),
            folder_context=infer_folder_label(display_name)
        )


def build_batch_response(
    results: List[FilePredictionResult],
    batch_type: str,
    archive_name: Optional[str] = None
) -> BatchPredictionResponse:
    """Aggregate individual file prediction results into a summary response."""
    successful = [r for r in results if r.status == "success"]
    failed = [r for r in results if r.status == "failed"]

    adhd_count = sum(1 for r in successful if r.prediction == "ADHD")
    control_count = sum(1 for r in successful if r.prediction == "Control")

    summary = BatchSummary(
        total_files=len(results),
        successful_files=len(successful),
        failed_files=len(failed),
        adhd_predictions=adhd_count,
        control_predictions=control_count
    )

    overall_status = "success" if len(successful) > 0 else "failed"

    return BatchPredictionResponse(
        batch_type=batch_type,
        archive_name=archive_name,
        summary=summary,
        results=results,
        status=overall_status
    )


@router.post("/api/predict", response_model=BatchPredictionResponse)
@router.post("/api/predict/batch", response_model=BatchPredictionResponse)
@router.post("/predict-adhd")
async def predict_eeg_endpoint(
    files: List[UploadFile] = File(...),
    sampling_rate: Optional[float] = Form(None)
):
    """
    Predict ADHD vs Control on one or more uploaded EEG recordings (or a ZIP archive).
    Accepts .mat, .csv, .tsv, .txt, .npy, .npz, .edf, .fif, .set, and .zip files.
    """
    if not files:
        raise HTTPException(status_code=400, detail="No EEG files were uploaded.")

    temp_dir = Path(tempfile.mkdtemp(prefix="adhd_pred_"))

    try:
        # Sanitize sampling_rate override: ignore 0 or negative values
        valid_fs: Optional[float] = None
        if sampling_rate is not None:
            try:
                fs_val = float(sampling_rate)
                if fs_val > 0.0:
                    valid_fs = fs_val
            except (ValueError, TypeError):
                valid_fs = None

        # CASE 1: Single ZIP archive upload
        if len(files) == 1 and safe_upload_filename(files[0].filename).lower().endswith(".zip"):
            upload = files[0]
            archive_name = safe_upload_filename(upload.filename)
            archive_path = temp_dir / archive_name
            copy_upload_with_limit(upload, archive_path)

            extract_path = temp_dir / "extracted_dataset"
            extract_path.mkdir(parents=True, exist_ok=True)
            eeg_files, _ = extract_zip_archive_safely(archive_path, extract_path)

            if not eeg_files:
                raise ValueError("No supported EEG recordings found in the ZIP archive.")

            results: List[FilePredictionResult] = []
            for path in eeg_files:
                relative_name = str(path.relative_to(extract_path))
                res = predict_single_eeg_file(
                    path,
                    relative_name,
                    sampling_rate_override=valid_fs
                )
                results.append(res)

            return build_batch_response(results, batch_type="zip_archive", archive_name=archive_name)

        # CASE 2: Multiple (or single) individual EEG files
        results: List[FilePredictionResult] = []
        for idx, upload in enumerate(files):
            safe_name = safe_upload_filename(upload.filename)
            validate_extension(safe_name)
            stored_path = temp_dir / f"{idx}_{safe_name}"
            copy_upload_with_limit(upload, stored_path)

            res = predict_single_eeg_file(
                stored_path,
                safe_name,
                sampling_rate_override=valid_fs
            )
            results.append(res)

        batch_type = "single_file" if len(files) == 1 else "multiple_files"
        return build_batch_response(results, batch_type=batch_type)

    except HTTPException:
        raise
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=f"Processing error: {exc}")
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Backend error: {exc}")
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)
