import re
import shutil
from pathlib import Path
from typing import Optional
from fastapi import UploadFile

from app.config import (
    MAX_UPLOAD_BYTES,
    SUPPORTED_EXTENSIONS,
    LABEL_MAP
)


def safe_upload_filename(filename: Optional[str]) -> str:
    """Validate and sanitize uploaded file name."""
    name = Path(filename or "").name.strip()
    if not name or name in {".", ".."}:
        raise ValueError("Each uploaded file must include a valid file name.")
    # Check for path traversal characters
    if ".." in name or "/" in name or "\\" in name:
        raise ValueError("File name contains unsafe path characters.")
    return name


def validate_extension(filename: str) -> str:
    """Validate that the file has a supported EEG extension or is a ZIP archive."""
    ext = Path(filename).suffix.lower()
    if ext != ".zip" and ext not in SUPPORTED_EXTENSIONS:
        raise ValueError(
            f"Unsupported file format '{ext}'. "
            f"Supported EEG formats are: {', '.join(sorted(SUPPORTED_EXTENSIONS))} and .zip"
        )
    return ext


def copy_upload_with_limit(
    upload: UploadFile,
    destination: Path,
    max_bytes: int = MAX_UPLOAD_BYTES
) -> int:
    """Safely stream upload to destination with byte size limit."""
    total = 0
    destination.parent.mkdir(parents=True, exist_ok=True)
    with open(destination, "wb") as output:
        while True:
            chunk = upload.file.read(1024 * 1024)
            if not chunk:
                break
            total += len(chunk)
            if total > max_bytes:
                raise ValueError(
                    f"Upload exceeds the maximum file size limit of "
                    f"{max_bytes // (1024 * 1024)} MB."
                )
            output.write(chunk)
    return total


def infer_folder_label(path_str: str) -> str:
    """
    Infer ADHD or Control from filename and innermost folder context.
    Avoids false positives from long dataset archive root names like
    'A Dataset of EEG Signals from Adults with ADHD and Healthy Controls...'.
    """
    p = Path(path_str)
    stem_lower = p.stem.lower()

    # 1. Check exact filename tokens first (e.g. FC, MC, FADHD, MADHD)
    if stem_lower in {"fc", "mc", "control", "normal", "healthy", "hc"}:
        return "Control"
    if stem_lower in {"fadhd", "madhd", "adhd", "patient", "case"}:
        return "ADHD"

    # Filename contains keyword
    if "adhd" in stem_lower and "non" not in stem_lower and "control" not in stem_lower:
        return "ADHD"
    if any(k in stem_lower for k in ["control", "healthy", "normal", "nonadhd", "non-adhd"]):
        return "Control"

    # 2. Check path parts starting from the innermost folder outwards
    for part in reversed(p.parts[:-1]):
        folder = part.strip().lower()
        # Skip outer container names that mention both classes simultaneously
        if "adhd" in folder and ("control" in folder or "healthy" in folder):
            continue

        if folder in {"adhd", "patients", "cases", "patient", "case"}:
            return "ADHD"
        if folder in {"control", "controls", "healthy", "hc", "normal", "nonadhd", "non-adhd"}:
            return "Control"

    return "Unknown"
