from pathlib import Path
from typing import List, Optional
import mne
import numpy as np

from app.parsers.base import EEGRecording
from app.preprocessing.channels import detect_and_orient_time_dimension
from app.utils.logging import log_pipeline_step


def read_edf_eeg_file(
    path: Path,
    sampling_rate_override: Optional[float] = None
) -> EEGRecording:
    """
    Parse EDF (.edf), FIF (.fif), and EEGLAB (.set) files using MNE.
    """
    ext = path.suffix.lower()
    warnings: List[str] = []

    try:
        if ext == ".edf":
            raw = mne.io.read_raw_edf(path, preload=True, verbose="ERROR")
        elif ext == ".fif":
            raw = mne.io.read_raw_fif(path, preload=True, verbose="ERROR")
        elif ext == ".set":
            raw = mne.io.read_raw_eeglab(path, preload=True, verbose="ERROR")
        else:
            raise ValueError(f"Unsupported MNE file format: '{ext}'.")
    except Exception as exc:
        raise ValueError(f"Could not load EDF/MNE recording '{path.name}': {exc}")

    # Pick EEG channels
    picks = mne.pick_types(raw.info, eeg=True, exclude="bads")
    if len(picks) < 2:
        # Fallback: pick all channels if channels weren't explicitly typed as EEG
        picks = list(range(len(raw.ch_names)))
        if len(picks) < 2:
            raise ValueError(f"File '{path.name}' contains fewer than 2 valid channels.")
        warnings.append(
            f"EDF channels were not explicitly tagged as EEG; using all {len(picks)} available channels."
        )

    # raw.get_data() returns shape (channels, time) -> transpose to (time, channels)
    data = raw.get_data(picks=picks).T.astype(np.float64)
    channel_names = [raw.ch_names[i] for i in picks]

    detected_fs = sampling_rate_override or float(raw.info["sfreq"])

    # Ensure orientation is (time, channels)
    data, transposed = detect_and_orient_time_dimension(data, channel_names)
    if transposed:
        warnings.append("Transposed MNE data array to (time, channels).")

    log_pipeline_step(
        "PARSER",
        f"Parsed MNE ({ext.upper()}): shape {data.shape}, channels={len(channel_names)}, fs={detected_fs:g} Hz"
    )

    return EEGRecording(
        data=data,
        sampling_rate=detected_fs,
        channel_names=channel_names,
        source_format=f"EDF/MNE ({ext.upper()})",
        file_name=path.name,
        original_shape=data.shape,
        warnings=warnings,
        metadata={
            "sfreq": float(raw.info["sfreq"]),
            "n_channels": len(channel_names)
        }
    )
