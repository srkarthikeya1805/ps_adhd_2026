import math
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple
import h5py
import numpy as np
import scipy.io as sio

from app.config import REQUIRED_CHANNELS, TARGET_FS
from app.parsers.base import EEGRecording
from app.preprocessing.channels import detect_and_orient_time_dimension
from app.utils.logging import log_pipeline_step


def convert_3d_to_2d_eeg(arr: np.ndarray) -> np.ndarray:
    """
    Convert a 3D EEG tensor (trials x time x channels, or channels x time x trials)
    into a continuous (time, channels) 2D signal array.
    """
    if not isinstance(arr, np.ndarray) or arr.ndim != 3:
        return arr

    a, b, c = arr.shape
    # Pattern A: (trials, samples, channels) e.g. (13, 7680, 2)
    if b >= 64 and c <= 256:
        return arr.reshape(-1, c)

    # Pattern B: (channels, samples, trials) e.g. (2, 7680, 13)
    if a <= 256 and b >= 64:
        return arr.transpose(2, 1, 0).reshape(-1, a)

    # Pattern C: (samples, channels, trials)
    if a >= 64 and b <= 256:
        return arr.transpose(2, 0, 1).reshape(-1, b)

    # Fallback: flatten first two dimensions
    return arr.reshape(-1, arr.shape[-1])


def is_signal_candidate(arr: np.ndarray) -> bool:
    """Check if array looks like candidate EEG signal data (2D or 3D)."""
    if not isinstance(arr, np.ndarray):
        return False
    if not np.issubdtype(arr.dtype, np.number):
        return False
    if arr.ndim == 2:
        r, c = arr.shape
        return min(r, c) >= 1 and max(r, c) >= 32
    if arr.ndim == 3:
        return any(d >= 64 for d in arr.shape) and any(d <= 256 for d in arr.shape)
    return False


def extract_numeric_arrays_recursively(
    obj: Any,
    prefix: str = "root",
    visited: Optional[Set[int]] = None
) -> List[Tuple[str, np.ndarray]]:
    """
    Recursively search MATLAB structures for candidate numeric arrays.
    Handles:
      - Plain numeric 2D and 3D ndarrays
      - Object ndarrays and cell arrays (e.g. Mendeley FC/MC/MADHD/FADHD subject cells)
      - MATLAB structs (scipy mat_struct)
      - Dictionaries
      - Lists / tuples
    """
    if visited is None:
        visited = set()

    obj_id = id(obj)
    if obj_id in visited:
        return []
    visited.add(obj_id)

    candidates: List[Tuple[str, np.ndarray]] = []

    # 1. Plain numeric or object ndarray
    if isinstance(obj, np.ndarray):
        # 1a. Numeric array
        if np.issubdtype(obj.dtype, np.number):
            if obj.ndim == 3:
                arr_2d = convert_3d_to_2d_eeg(obj)
                if is_signal_candidate(arr_2d):
                    candidates.append((prefix, np.asarray(arr_2d, dtype=np.float64)))
                return candidates
            if is_signal_candidate(obj):
                candidates.append((prefix, np.asarray(obj, dtype=np.float64)))
            return candidates

        # 1b. Object ndarray / cell array (Mendeley subject groups or trial collections)
        if obj.dtype == object:
            numeric_items = []
            for idx, item in np.ndenumerate(obj):
                if isinstance(item, np.ndarray) and np.issubdtype(item.dtype, np.number):
                    if item.ndim == 3:
                        c2d = convert_3d_to_2d_eeg(item)
                        if is_signal_candidate(c2d):
                            numeric_items.append(c2d)
                    elif item.ndim == 2 and is_signal_candidate(item):
                        numeric_items.append(item)

            if numeric_items:
                try:
                    aligned = []
                    min_ch = min(
                        c.shape[1] if c.shape[0] >= c.shape[1] else c.shape[0]
                        for c in numeric_items
                    )
                    for c in numeric_items:
                        if c.shape[0] < c.shape[1] and c.shape[0] <= 128:
                            c = c.T
                        aligned.append(c[:, :min_ch])
                    concat = np.concatenate(aligned, axis=0)
                    candidates.append((f"{prefix}_all", np.asarray(concat, dtype=np.float64)))
                except Exception:
                    pass

            # Also recursively inspect individual elements
            for idx, item in np.ndenumerate(obj):
                sub_prefix = f"{prefix}[{','.join(map(str, idx))}]"
                candidates.extend(extract_numeric_arrays_recursively(item, sub_prefix, visited))
            return candidates

        # 1c. Structured ndarray with field names
        if obj.dtype.names:
            for name in obj.dtype.names:
                try:
                    candidates.extend(
                        extract_numeric_arrays_recursively(obj[name], f"{prefix}.{name}", visited)
                    )
                except Exception:
                    pass
            return candidates

    # 2. Dictionary
    if isinstance(obj, dict):
        for k, v in obj.items():
            if str(k).startswith("__"):
                continue
            candidates.extend(extract_numeric_arrays_recursively(v, f"{prefix}.{k}", visited))
        return candidates

    # 3. scipy.io mat_struct
    if hasattr(obj, "_fieldnames"):
        for field in obj._fieldnames:
            try:
                val = getattr(obj, field)
                candidates.extend(extract_numeric_arrays_recursively(val, f"{prefix}.{field}", visited))
            except Exception:
                pass
        return candidates

    # 4. List / Tuple
    if isinstance(obj, (list, tuple)):
        for i, item in enumerate(obj):
            candidates.extend(extract_numeric_arrays_recursively(item, f"{prefix}[{i}]", visited))

    return candidates


def score_candidate(name: str, arr: np.ndarray) -> float:
    """Score candidate array based on shape, dimensions, and variable name."""
    r, c = arr.shape
    score = math.log1p(arr.size)

    # Significant bonus if either dimension matches 19 channels
    if r == REQUIRED_CHANNELS or c == REQUIRED_CHANNELS:
        score += 50.0

    # Common EEG channel counts
    common_channels = {14, 16, 18, 19, 21, 24, 32, 64, 128}
    if r in common_channels or c in common_channels:
        score += 25.0

    # Large sample count bonus
    if max(r, c) >= 1280:
        score += 30.0
    elif max(r, c) >= 256:
        score += 15.0

    # Keyword bonuses
    lower_name = name.lower()
    for kw in ["eeg", "data", "signal", "raw", "trial", "v1p", "v21p", "fc", "mc", "fadhd", "madhd", "val", "x"]:
        if kw in lower_name:
            score += 10.0

    # Slight bonus for aggregated collections
    if "_all" in lower_name:
        score += 15.0

    return score


def select_best_eeg_array(candidates: List[Tuple[str, np.ndarray]]) -> Tuple[np.ndarray, str]:
    """Select the best candidate EEG array from the list of extracted candidates."""
    if not candidates:
        raise ValueError("No numeric EEG array could be located inside the MATLAB file.")

    scored = []
    for name, arr in candidates:
        if is_signal_candidate(arr):
            s = score_candidate(name, arr)
            scored.append((s, name, arr))

    if not scored:
        raise ValueError(
            "The MATLAB file contains numeric data, but none resembles a valid EEG signal."
        )

    scored.sort(key=lambda item: item[0], reverse=True)
    best_score, best_name, best_arr = scored[0]
    return best_arr, best_name


def find_mat_sampling_rate(obj: Any, visited: Optional[Set[int]] = None) -> Optional[float]:
    """Recursively search for sampling rate metadata in MATLAB object."""
    if visited is None:
        visited = set()

    obj_id = id(obj)
    if obj_id in visited:
        return None
    visited.add(obj_id)

    preferred_keys = ["fs", "Fs", "FS", "sampling_rate", "sample_rate", "srate", "sfreq", "frequency"]

    # Check dict
    if isinstance(obj, dict):
        for k in preferred_keys:
            if k in obj:
                try:
                    val = np.asarray(obj[k]).squeeze()
                    if val.size == 1:
                        fs = float(val)
                        if 1.0 <= fs <= 10000.0:
                            return fs
                except Exception:
                    pass

        for k, v in obj.items():
            if str(k).startswith("__"):
                continue
            res = find_mat_sampling_rate(v, visited)
            if res is not None:
                return res

    # Check mat_struct
    if hasattr(obj, "_fieldnames"):
        for f in obj._fieldnames:
            if str(f).lower() in {"fs", "sampling_rate", "sample_rate", "srate", "sfreq"}:
                try:
                    val = np.asarray(getattr(obj, f)).squeeze()
                    if val.size == 1:
                        fs = float(val)
                        if 1.0 <= fs <= 10000.0:
                            return fs
                except Exception:
                    pass

    # Check ndarray (object array or structured array)
    if isinstance(obj, np.ndarray):
        if obj.dtype.names:
            for f in obj.dtype.names:
                try:
                    res = find_mat_sampling_rate(obj[f], visited)
                    if res is not None:
                        return res
                except Exception:
                    pass
        if obj.dtype == object or obj.dtype.kind in {"V", "O"}:
            for item in obj.flat:
                res = find_mat_sampling_rate(item, visited)
                if res is not None:
                    return res

    return None


def find_mat_channel_names(obj: Any, visited: Optional[Set[int]] = None) -> Optional[List[str]]:
    """Search MATLAB structure for channel labels."""
    if visited is None:
        visited = set()

    obj_id = id(obj)
    if obj_id in visited:
        return None
    visited.add(obj_id)

    keys = ["channels", "clab", "labels", "chanlocs", "channel_names", "ch_names"]

    if isinstance(obj, dict):
        for k in keys:
            if k in obj:
                try:
                    val = obj[k]
                    if isinstance(val, (list, tuple, np.ndarray)):
                        names = [str(item).strip() for item in np.asarray(val).ravel() if str(item).strip()]
                        if len(names) >= 2:
                            return names
                except Exception:
                    pass

        for k, v in obj.items():
            if str(k).startswith("__"):
                continue
            res = find_mat_channel_names(v, visited)
            if res is not None:
                return res

    if hasattr(obj, "_fieldnames"):
        for f in obj._fieldnames:
            if str(f).lower() in {"channels", "clab", "labels", "chanlocs", "ch_names"}:
                try:
                    val = getattr(obj, f)
                    if isinstance(val, (list, tuple, np.ndarray)):
                        names = [str(item).strip() for item in np.asarray(val).ravel() if str(item).strip()]
                        if len(names) >= 2:
                            return names
                except Exception:
                    pass

        for f in obj._fieldnames:
            res = find_mat_channel_names(getattr(obj, f), visited)
            if res is not None:
                return res

    # Check ndarray (object array or structured array)
    if isinstance(obj, np.ndarray):
        if obj.dtype.names:
            for f in obj.dtype.names:
                if str(f).lower() in {"channels", "clab", "labels", "chanlocs", "ch_names"}:
                    try:
                        val = obj[f]
                        names = [str(item).strip() for item in np.asarray(val).ravel() if str(item).strip()]
                        if len(names) >= 2:
                            return names
                    except Exception:
                        pass
            for f in obj.dtype.names:
                try:
                    res = find_mat_channel_names(obj[f], visited)
                    if res is not None:
                        return res
                except Exception:
                    pass
        if obj.dtype == object or obj.dtype.kind in {"V", "O"}:
            for item in obj.flat:
                res = find_mat_channel_names(item, visited)
                if res is not None:
                    return res

    return None


def read_mat_file(path: Path, sampling_rate_override: Optional[float] = None) -> EEGRecording:
    """
    Parse a MATLAB .mat file (numeric matrix, Mendeley structured object, or HDF5 v7.3).

    Parameters:
        path: Path to .mat file
        sampling_rate_override: Optional user-supplied sampling rate

    Returns:
        EEGRecording standard object
    """
    warnings: List[str] = []
    candidates: List[Tuple[str, np.ndarray]] = []
    fs: Optional[float] = (
        float(sampling_rate_override)
        if (sampling_rate_override is not None and float(sampling_rate_override) > 0)
        else None
    )
    channel_names: Optional[List[str]] = None
    format_type = "MATLAB"

    # Attempt 1: Standard MATLAB (v5 / v7) via scipy.io
    try:
        mat_dict = sio.loadmat(path, squeeze_me=False, struct_as_record=False)
        candidates = extract_numeric_arrays_recursively(mat_dict)

        if fs is None:
            fs = find_mat_sampling_rate(mat_dict)

        channel_names = find_mat_channel_names(mat_dict)

    except Exception as std_error:
        # Attempt 2: MATLAB v7.3 (HDF5 based)
        try:
            with h5py.File(path, "r") as f:
                def visitor(name, obj):
                    if isinstance(obj, h5py.Dataset):
                        try:
                            if len(obj.shape) == 2 and is_signal_candidate(np.empty(obj.shape)):
                                data_slice = np.asarray(obj[()], dtype=np.float64)
                                candidates.append((name, data_slice))
                            elif len(obj.shape) == 3 and is_signal_candidate(np.empty(obj.shape)):
                                data_slice = np.asarray(obj[()], dtype=np.float64)
                                c2d = convert_3d_to_2d_eeg(data_slice)
                                candidates.append((name, c2d))
                        except Exception:
                            pass
                f.visititems(visitor)

            format_type = "MATLAB v7.3 (HDF5)"
            warnings.append("MATLAB v7.3 / HDF5 container format detected.")

        except Exception as hdf_error:
            raise ValueError(
                f"Failed to read MATLAB file '{path.name}'. "
                f"Standard parser error: {std_error}. "
                f"HDF5 parser error: {hdf_error}."
            )

    raw_arr, selected_var_name = select_best_eeg_array(candidates)

    # Detect and normalize orientation to (time, channels)
    oriented_arr, transposed = detect_and_orient_time_dimension(raw_arr, channel_names)
    if transposed:
        warnings.append(
            f"Transposed matrix from {raw_arr.shape} to (samples={oriented_arr.shape[0]}, "
            f"channels={oriented_arr.shape[1]})."
        )

    # Sampling rate fallback handling
    if fs is None or fs <= 0:
        fs = TARGET_FS
        warnings.append(
            f"Sampling rate was not found in MATLAB metadata; using default {TARGET_FS:g} Hz."
        )

    log_pipeline_step(
        "PARSER",
        f"Parsed MAT: variable '{selected_var_name}', shape {oriented_arr.shape}, fs={fs} Hz"
    )

    return EEGRecording(
        data=oriented_arr,
        sampling_rate=fs,
        channel_names=channel_names,
        source_format=format_type,
        file_name=path.name,
        original_shape=raw_arr.shape,
        warnings=warnings,
        metadata={
            "variable_name": selected_var_name,
            "candidates_found": len(candidates)
        }
    )
