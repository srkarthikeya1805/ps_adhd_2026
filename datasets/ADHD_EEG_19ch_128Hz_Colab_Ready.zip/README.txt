ADHD EEG 19-channel, 128 Hz Colab-ready dataset

Classes:
- ADHD: 61 subjects
- Control: 60 subjects
- Total: 121 subjects

Each .mat file contains one EEG recording as a numeric matrix with shape (samples, 19).
Sampling rate: 128 Hz.
Channel order (matching Standard-10-20-Cap19new.ced):
Fp1, Fp2, F7, F3, Fz, F4, F8, T7, C3, Cz, C4, T8, P7, P3, Pz, P4, P8, O1, O2

Use this dataset with the provided CNN+Transformer Colab notebook. The notebook reads the .mat files directly and assigns labels from the ADHD/Control folder.
Do not merge windows across subjects before splitting: the notebook performs subject-wise splitting.
